FIRST_QUESTIONS = {
    "en": "Hi, how are you?",
    "de": "Hallo, wie geht es dir?",
    "pt-br": "Oi como você está?",
    "he": "היי מה קורה?",
}
TERMINATES = {
    "en": "quit",
    "de": "ende",
    "pt-br": "sair",
    "he": "זהו"
}

LANGUAGE_SUPPORT = ["en", "de", "pt-br", "he"]
